--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2 (Homebrew)
-- Dumped by pg_dump version 15.2 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: gaetano
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE postgres OWNER TO gaetano;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: gaetano
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aste (
    id integer NOT NULL,
    immobile integer NOT NULL,
    acquirente character varying,
    prezzo_partenza integer NOT NULL,
    prezzo_corrente integer NOT NULL,
    fine bigint NOT NULL
);


ALTER TABLE public.aste OWNER TO postgres;

--
-- Name: aste_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aste_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.aste_id OWNER TO postgres;

--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id integer NOT NULL,
    immobile integer NOT NULL,
    img bytea NOT NULL
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.images_id OWNER TO postgres;

--
-- Name: immobili; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immobili (
    id integer NOT NULL,
    nome character varying NOT NULL,
    tipo character varying NOT NULL,
    prezzo double precision NOT NULL,
    descrizione character varying,
    metri_quadri double precision NOT NULL,
    indirizzo character varying NOT NULL,
    proprietario character varying NOT NULL,
    tipo_annuncio character varying NOT NULL
);


ALTER TABLE public.immobili OWNER TO postgres;

--
-- Name: immobili_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.immobili_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.immobili_id OWNER TO postgres;

--
-- Name: recensioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensioni (
    id integer NOT NULL,
    titolo character varying NOT NULL,
    rating smallint NOT NULL,
    autore character varying NOT NULL,
    immobile integer NOT NULL
);


ALTER TABLE public.recensioni OWNER TO postgres;

--
-- Name: recensioni_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensioni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recensioni_id OWNER TO postgres;

--
-- Name: utenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utenti (
    id character varying NOT NULL,
    nome character varying NOT NULL,
    cognome character varying NOT NULL,
    email character varying NOT NULL,
    telefono bigint,
    tipologia character varying NOT NULL,
    password character varying NOT NULL
);


ALTER TABLE public.utenti OWNER TO postgres;

--
-- Data for Name: aste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aste (id, immobile, acquirente, prezzo_partenza, prezzo_corrente, fine) FROM stdin;
\.
COPY public.aste (id, immobile, acquirente, prezzo_partenza, prezzo_corrente, fine) FROM '$$PATH$$/3638.dat';

--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, immobile, img) FROM stdin;
\.
COPY public.images (id, immobile, img) FROM '$$PATH$$/3645.dat';

--
-- Data for Name: immobili; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.immobili (id, nome, tipo, prezzo, descrizione, metri_quadri, indirizzo, proprietario, tipo_annuncio) FROM stdin;
\.
COPY public.immobili (id, nome, tipo, prezzo, descrizione, metri_quadri, indirizzo, proprietario, tipo_annuncio) FROM '$$PATH$$/3639.dat';

--
-- Data for Name: recensioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensioni (id, titolo, rating, autore, immobile) FROM stdin;
\.
COPY public.recensioni (id, titolo, rating, autore, immobile) FROM '$$PATH$$/3641.dat';

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utenti (id, nome, cognome, email, telefono, tipologia, password) FROM stdin;
\.
COPY public.utenti (id, nome, cognome, email, telefono, tipologia, password) FROM '$$PATH$$/3643.dat';

--
-- Name: aste_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aste_id', 8, true);


--
-- Name: images_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id', 1, false);


--
-- Name: immobili_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.immobili_id', 16, true);


--
-- Name: recensioni_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensioni_id', 1, false);


--
-- Name: aste aste_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_pk PRIMARY KEY (id);


--
-- Name: images images_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pk PRIMARY KEY (id);


--
-- Name: immobili immobili_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT immobili_pk PRIMARY KEY (id);


--
-- Name: recensioni recensioni_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_pk PRIMARY KEY (id);


--
-- Name: utenti utenti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utenti
    ADD CONSTRAINT utenti_pk PRIMARY KEY (id);


--
-- Name: aste aste_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_fk_1 FOREIGN KEY (immobile) REFERENCES public.immobili(id) ON DELETE CASCADE;


--
-- Name: aste aste_fk_2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_fk_2 FOREIGN KEY (acquirente) REFERENCES public.utenti(id);


--
-- Name: images images_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_fk FOREIGN KEY (immobile) REFERENCES public.immobili(id) ON DELETE CASCADE;


--
-- Name: immobili immobili_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT immobili_fk FOREIGN KEY (proprietario) REFERENCES public.utenti(id) ON DELETE CASCADE;


--
-- Name: recensioni recensioni_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_fk FOREIGN KEY (immobile) REFERENCES public.immobili(id);


--
-- Name: recensioni recensioni_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_fk_1 FOREIGN KEY (autore) REFERENCES public.utenti(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO pg_database_owner;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

